import React, { useState } from 'react';
import Header from './components/Header';
import Players from './components/Players';
import Schedule from './components/Schedule';
import Footer from './components/Footer';

export type View = 'schedule' | 'players';

const App: React.FC = () => {
  const [view, setView] = useState<View>('schedule');

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 font-sans">
      <div className="absolute top-0 left-0 w-full h-full bg-grid-slate-700/[0.2] [mask-image:linear-gradient(to_bottom,white_20%,transparent_100%)]"></div>
      <div className="relative z-10 flex flex-col min-h-screen">
        <Header currentView={view} setView={setView} />
        <main className="flex-grow container mx-auto px-4 py-8">
          {view === 'schedule' ? <Schedule /> : <Players />}
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default App;