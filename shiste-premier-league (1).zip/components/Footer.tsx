import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900/50 border-t border-slate-700/50 mt-12">
      <div className="container mx-auto px-4 py-6 text-center text-slate-400">
        <p>&copy; {new Date().getFullYear()} Shiste Premier League. All Rights Reserved.</p>
        <p className="text-xs mt-1">
          Designed with passion for the love of cricket.
        </p>
      </div>
    </footer>
  );
};

export default Footer;