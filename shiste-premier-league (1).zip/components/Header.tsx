import React from 'react';
import type { View } from '../App';
import { CricketBatIcon } from './icons/CricketBatIcon';

interface HeaderProps {
  currentView: View;
  setView: (view: View) => void;
}

const DetailItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div className="flex items-baseline gap-1.5">
        <span className="text-slate-500">{label}:</span>
        <span className="font-semibold text-slate-300">{value}</span>
    </div>
);

const NavButton: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`relative px-4 py-2 text-sm md:text-base font-medium transition-colors duration-300 ${
        isActive ? 'text-fuchsia-400' : 'text-slate-300 hover:text-white'
      }`}
    >
      {label}
      {isActive && (
        <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3/5 h-0.5 bg-fuchsia-400 rounded-full"></span>
      )}
    </button>
  );
};

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  return (
    <header className="bg-slate-900/70 backdrop-blur-lg border-b border-slate-700/50 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-3">
            <CricketBatIcon className="h-8 w-8 text-fuchsia-400" />
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white tracking-tight leading-tight">
                Shiste Premier <span className="text-fuchsia-400">League</span>
              </h1>
              <p className="text-xs text-slate-400 -mt-0.5">SPL 2025</p>
            </div>
          </div>
          <nav className="flex items-center bg-slate-800/50 rounded-full p-1 border border-slate-700">
            <NavButton
              label="Schedule"
              isActive={currentView === 'schedule'}
              onClick={() => setView('schedule')}
            />
            <NavButton
              label="Players"
              isActive={currentView === 'players'}
              onClick={() => setView('players')}
            />
          </nav>
        </div>
      </div>
      <div className="border-t border-slate-700/50 bg-slate-900/40">
        <div className="container mx-auto px-4 py-2 flex items-center justify-center md:justify-between flex-wrap gap-x-6 gap-y-1 text-xs sm:text-sm">
            <DetailItem label="Organized by" value="UK Warriors" />
            <DetailItem label="Season" value="4" />
            <DetailItem label="Venue" value="Wakde Mal, Shiste" />
            <DetailItem label="Date" value="3 September 2025" />
        </div>
      </div>
    </header>
  );
};

export default Header;