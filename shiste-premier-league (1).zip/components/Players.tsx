import React, { useState } from 'react';
import { TEAMS } from '../constants';
import type { Player, Team } from '../types';
import { ChevronLeftIcon } from './icons/ChevronLeftIcon';


const RoleBadge: React.FC<{ role: Player['role'] }> = ({ role }) => {
  const roleColors: { [key: string]: string } = {
    'Captain': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    'Vice-Captain': 'bg-orange-500/20 text-orange-300 border-orange-500/30',
    'Coach': 'bg-red-500/20 text-red-300 border-red-500/30',
    'Team Owner': 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30',
    'Team Manager': 'bg-green-500/20 text-green-300 border-green-500/30',
    'Head Coach': 'bg-red-500/20 text-red-300 border-red-500/30',
    'Batting Coach': 'bg-sky-500/20 text-sky-300 border-sky-500/30',
    'Bowling Coach': 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    'Fielding Coach': 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    'Wicket-Keeper': 'bg-teal-500/20 text-teal-300 border-teal-500/30',
    'Player': 'bg-transparent text-slate-400 border-transparent',
  };
  
  if (role === 'Player') return null;

  return (
    <span className={`ml-2 flex-shrink-0 inline-block px-2 py-0.5 text-xs font-semibold rounded-full border whitespace-nowrap ${roleColors[role]}`}>
      {role}
    </span>
  );
};

const TeamCard: React.FC<{ team: Team; onSelect: () => void }> = ({ team, onSelect }) => {
  return (
    <div 
      onClick={onSelect}
      className="bg-slate-800/60 border border-slate-700 rounded-lg p-5 flex flex-col items-center justify-center gap-4 transition-all duration-300 hover:border-fuchsia-400/50 hover:bg-slate-800 cursor-pointer text-center"
    >
        <img src={team.logo} alt={`${team.name} Logo`} className="w-24 h-24 rounded-full object-cover bg-slate-700 shadow-lg"/>
        <h3 className="text-xl font-bold text-white mt-2">{team.name}</h3>
        <p className="text-slate-400 text-sm">{team.squad.length} members</p>
    </div>
  )
}

const SquadView: React.FC<{ team: Team; onBack: () => void}> = ({ team, onBack }) => {
    const heroPlayer = team.squad.find(p => p.role === 'Captain') || team.squad[0];
    const { gradientFrom, gradientVia, gradientTo, accent, heroTextColor } = team.theme;

    const staffRoles = ['Team Owner', 'Team Manager', 'Batting Coach', 'Bowling Coach', 'Head Coach', 'Fielding Coach', 'Coach'];
    const displayGroupedStaff = team.displayFormat === 'grouped_staff';

    const staff = displayGroupedStaff
      ? team.squad.filter(p => staffRoles.includes(p.role))
      : [];
    
    const players = (displayGroupedStaff
      ? team.squad.filter(p => !staffRoles.includes(p.role))
      : [...team.squad]
    ).sort((a, b) => a.id - b.id);

    const groupedPlayers = players.reduce((acc, player) => {
        const category = player.category || 'Players';
        if (!acc[category]) {
            acc[category] = [];
        }
        acc[category].push(player);
        return acc;
    }, {} as Record<string, Player[]>);
    
    const categoryOrder: (keyof typeof groupedPlayers)[] = ['Batsman', 'All Rounder', 'Bowler', 'Stand by', 'Players'];

    return (
        <div>
            <button onClick={onBack} className="flex items-center gap-2 text-fuchsia-400 hover:text-fuchsia-300 font-semibold mb-6 transition-colors">
                <ChevronLeftIcon className="w-5 h-5" />
                Back to Teams
            </button>
            <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 items-start">
                <div className="lg:w-5/12 xl:w-2/5 flex flex-col">
                    <div className={`relative p-8 rounded-2xl border border-slate-700 h-full flex flex-col justify-between overflow-hidden bg-gradient-to-br ${gradientFrom} ${gradientVia} ${gradientTo}`}>
                        <img 
                          src={team.logo}
                          alt={`${team.name} Logo`}
                          className="absolute top-4 right-4 w-24 h-24 md:w-28 md:h-28 z-20 drop-shadow-lg"
                        />
                        <div className='z-10'>
                          <h2 className={`text-6xl md:text-7xl font-extrabold ${heroTextColor} tracking-tighter`} style={{fontStyle: 'italic'}}>SQUAD</h2>
                          <h3 className={`text-3xl md:text-4xl font-bold ${accent} -mt-2 uppercase`}>{team.name}</h3>
                        </div>
                        <div className="relative mt-6 flex-grow flex items-end min-h-[300px]">
                            {heroPlayer && <img 
                                src={heroPlayer.imageUrl} 
                                alt={heroPlayer.name} 
                                className="absolute -bottom-8 -right-8 w-[120%] h-auto object-contain object-bottom drop-shadow-[0_20px_20px_rgba(0,0,0,0.5)]"
                            />}
                        </div>
                    </div>
                </div>

                <div className="lg:w-7/12 xl:w-3/5">
                    <div className="bg-slate-800/50 border border-slate-700/80 rounded-2xl p-4 md:p-6 h-full">
                        <div className="space-y-4 max-h-[550px] lg:max-h-full overflow-y-auto pr-2 custom-scrollbar">
                            {categoryOrder.map(category => {
                                if (!groupedPlayers[category]) return null;
                                return (
                                    <div key={category}>
                                        <h4 className="text-sm font-bold uppercase text-fuchsia-400 tracking-widest mb-2 sticky top-0 bg-slate-800/50 py-1">#{category === 'Players' ? team.name.replace(/\s/g, '') : category.replace(' ', '')}</h4>
                                        <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                                        {groupedPlayers[category].map((player) => (
                                            <li key={player.id} className="flex items-center justify-between p-3 bg-slate-900/40 rounded-lg border border-slate-700/70 hover:bg-slate-700/70 hover:border-fuchsia-400/30 transition-all duration-200">
                                            <div className="flex items-center overflow-hidden">
                                                <span className="text-slate-400 font-mono text-sm w-8 flex-shrink-0">{player.id}.</span>
                                                <span className="font-medium text-slate-100 truncate">{player.name}</span>
                                            </div>
                                            <RoleBadge role={player.role} />
                                            </li>
                                        ))}
                                        </ul>
                                    </div>
                                )
                            })}

                            {staff.length > 0 && (
                                <div>
                                    <h4 className="text-sm font-bold uppercase text-fuchsia-400 tracking-widest mt-6 mb-2 sticky top-0 bg-slate-800/50 py-1">#Management & Staff</h4>
                                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2">
                                        {staff.sort((a,b) => a.id - b.id).map(person => (
                                             <li key={person.id} className="flex items-center justify-between p-3 bg-slate-900/40 rounded-lg border border-slate-700/70">
                                                <span className="font-medium text-slate-100 truncate">{person.name}</span>
                                                <RoleBadge role={person.role} />
                                             </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

const Players: React.FC = () => {
    const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
    
    if (selectedTeam) {
        return <SquadView team={selectedTeam} onBack={() => setSelectedTeam(null)} />;
    }

  return (
    <div className="container mx-auto">
        <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-white">League Teams</h2>
            <p className="text-slate-400">Browse the squads for the Shiste Premier League 2025.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {TEAMS.map(team => (
                <TeamCard key={team.name} team={team} onSelect={() => setSelectedTeam(team)} />
            ))}
        </div>
    </div>
  );
};

export default Players;