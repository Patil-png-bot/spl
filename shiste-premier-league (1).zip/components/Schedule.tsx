import React, { useState } from 'react';
import { MATCHES, TEAMS } from '../constants';
import type { Match } from '../types';
import { CricketBallIcon } from './icons/CricketBallIcon';

const teamLogos = TEAMS.reduce((acc, team) => {
    acc[team.name] = team.logo;
    return acc;
}, {} as Record<string, string>);

const TeamLogo: React.FC<{ teamName: string }> = ({ teamName }) => {
    const logoSrc = teamLogos[teamName];
    if (teamName === 'TBD' || !logoSrc) {
        return (
            <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center font-bold text-fuchsia-400 flex-shrink-0">
                ?
            </div>
        );
    }

    return (
        <img src={logoSrc} alt={`${teamName} logo`} className="w-10 h-10 bg-slate-700 rounded-full object-cover flex-shrink-0" />
    )
}

const MatchCard: React.FC<{ match: Match }> = ({ match }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const timeFormatter = new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    const dateFormatter = new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    
    const startTime = match.date;
    const endTime = new Date(startTime.getTime() + 30 * 60000); // 30 minutes later

    return (
        <div className="bg-slate-800/60 border border-slate-700 rounded-lg transition-all duration-300 hover:border-fuchsia-400/50 hover:bg-slate-800">
            <div className="p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4 text-lg font-bold w-full sm:w-2/5 justify-end">
                    <span className="flex-1 text-right">{match.teamA}</span>
                    <TeamLogo teamName={match.teamA} />
                </div>
                <div className="flex flex-col items-center justify-center text-center">
                    <span className="text-xs text-slate-400">{dateFormatter.format(startTime)}</span>
                    <span className="text-sm font-bold text-fuchsia-400 mt-1">
                        {timeFormatter.format(startTime)} - {timeFormatter.format(endTime)}
                    </span>
                    <span className="text-2xl font-extrabold text-slate-500 my-1">VS</span>
                    <span className="text-xs text-slate-400 max-w-[150px] truncate">{match.venue}</span>
                </div>
                <div className="flex items-center gap-4 text-lg font-bold w-full sm:w-2/5 justify-start">
                    <TeamLogo teamName={match.teamB} />
                    <span className="flex-1 text-left">{match.teamB}</span>
                </div>
            </div>
            {(match.playing11A && match.playing11B && match.playing11A.length > 0 && match.playing11B.length > 0) && (
                <div className="border-t border-slate-700/50 px-5 py-3 text-center">
                    <button onClick={() => setIsExpanded(!isExpanded)} className="text-fuchsia-400 text-sm font-semibold hover:text-fuchsia-300 transition-colors">
                        {isExpanded ? 'Hide' : 'View'} Playing XI
                    </button>
                </div>
            )}
            {isExpanded && (
                <div className="border-t border-slate-700/50 p-5 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                    <div>
                        <h4 className="font-bold text-slate-200 mb-2 border-b border-slate-700 pb-1">{match.teamA}</h4>
                        <ul className="space-y-1.5 text-sm text-slate-300">
                            {match.playing11A?.map((player, i) => <li key={i} className="flex items-center gap-2"><span className="text-slate-500 w-5 text-right">{i+1}.</span>{player}</li>)}
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-200 mb-2 border-b border-slate-700 pb-1">{match.teamB}</h4>
                        <ul className="space-y-1.5 text-sm text-slate-300">
                            {match.playing11B?.map((player, i) => <li key={i} className="flex items-center gap-2"><span className="text-slate-500 w-5 text-right">{i+1}.</span>{player}</li>)}
                        </ul>
                    </div>
                </div>
            )}
        </div>
    );
};


const Schedule: React.FC = () => {
    const groupedMatches = MATCHES.reduce((acc, match) => {
        const stage = match.stage;
        if (!acc[stage]) {
            acc[stage] = [];
        }
        acc[stage].push(match);
        return acc;
    }, {} as Record<string, Match[]>);
    
    const stageOrder = ['Group Stage', 'Semi-Final 1', 'Semi-Final 2', 'Final'];

  return (
    <div>
        <h2 className="text-3xl font-bold text-center mb-2 text-white">Match Schedule</h2>
        <p className="text-center text-slate-400 mb-10">Upcoming clashes in the tournament.</p>
        <div className="space-y-10">
            {stageOrder.map((stage) => {
                const matchesForStage = groupedMatches[stage];
                if (!matchesForStage || matchesForStage.length === 0) return null;
                
                return (
                    <div key={stage}>
                        <div className="flex items-center gap-3 mb-4">
                            <CricketBallIcon className="w-5 h-5 text-fuchsia-400"/>
                            <h3 className="text-xl font-semibold text-slate-200">{stage}</h3>
                        </div>
                        <div className="space-y-4">
                            {matchesForStage.sort((a, b) => a.id - b.id).map(match => (
                                <MatchCard key={match.id} match={match} />
                            ))}
                        </div>
                    </div>
                )
            })}
        </div>
    </div>
  );
};

export default Schedule;