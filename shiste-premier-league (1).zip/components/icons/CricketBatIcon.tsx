import React from 'react';

export const CricketBatIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path
      d="M19.121 4.879l-1.414 1.414-2.828-2.828 1.414-1.414a2 2 0 012.828 0l0 0a2 2 0 010 2.828zM9.343 3.464l2.829 2.829-10.607 10.607-2.828-2.829 10.606-10.607zM3.586 16.293l4.242 4.243-1.414 1.414-4.243-4.243 1.415-1.414z"
    />
  </svg>
);
