import { Team, Player, Match } from './types';
import { 
    RISING_STARS_LOGO, 
    UK_WARRIORS_LOGO,
    SWARAJYA_LOGO,
    DJB_LOGO,
    ROYAL_AAGRI_LOGO,
    GAME_CHANGERS_LOGO
} from './assets/images';

const RISING_STARS_SQUAD: Player[] = [
  { id: 1, name: 'Prakash Kamble', team: 'Rising Stars', role: 'Team Owner', imageUrl: 'https://picsum.photos/seed/prakash/400/500' },
  { id: 2, name: 'Dashrath Dhumal', team: 'Rising Stars', role: 'Team Manager', imageUrl: 'https://picsum.photos/seed/dashrath/400/500' },
  { id: 3, name: 'Sujet Chalke', team: 'Rising Stars', role: 'Captain', imageUrl: 'https://picsum.photos/seed/sujet/400/500' },
  { id: 4, name: 'Raj Patil', team: 'Rising Stars', role: 'Vice-Captain', imageUrl: 'https://picsum.photos/seed/rajpatil/400/500' },
  { id: 5, name: 'Sanjay Kamble', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/sanjay/400/500' },
  { id: 6, name: 'Akshay Chalke', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/akshay/400/500' },
  { id: 7, name: 'Darshan Kamble', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/darshan/400/500' },
  { id: 8, name: 'Ajay Mohite', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/ajaym/400/500' },
  { id: 9, name: 'Harsh Chalke', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/harsh/400/500' },
  { id: 10, name: 'Shravan Kamble', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/shravan/400/500' },
  { id: 11, name: 'Nandan Nakti', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/nandan/400/500' },
  { id: 12, name: 'Ajay Bhayde', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/ajayb/400/500' },
  { id: 13, name: 'Sachin Mohite', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/sachin/400/500' },
  { id: 14, name: 'Vaibhav Patil', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/vaibhavp/400/500' },
  { id: 15, name: 'Jaydip Chalke', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/jaydip/400/500' },
  { id: 16, name: 'Pranamya Patil', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/pranamya/400/500' },
  { id: 17, name: 'Aayush Gharat', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/aayush/400/500' },
  { id: 18, name: 'Sujal Mohite', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/sujal/400/500' },
  { id: 19, name: 'Rushi Gharat', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/rushi/400/500' },
  { id: 20, name: 'Samir Kamble', team: 'Rising Stars', role: 'Player', imageUrl: 'https://picsum.photos/seed/samir/400/500' },
];

const UK_WARRIORS_SQUAD: Player[] = [
    { id: 1, name: 'Jaydeep Chalke', team: 'UK Warriors', role: 'Captain', imageUrl: 'https://picsum.photos/seed/jaydeepc/400/500' },
    { id: 2, name: 'Prafull Bhayde', team: 'UK Warriors', role: 'Vice-Captain', imageUrl: 'https://picsum.photos/seed/prafull/400/500' },
    { id: 3, name: 'Avinash Chalke', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/avinash/400/500' },
    { id: 4, name: 'Kumar Gharat', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/kumar/400/500' },
    { id: 5, name: 'Sarthak Patil', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/sarthak/400/500' },
    { id: 6, name: 'Siddesh Mohite', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/siddesh/400/500' },
    { id: 7, name: 'Ninad Patil', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/ninad/400/500' },
    { id: 8, name: 'Haresh Mohite', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/haresh/400/500' },
    { id: 9, name: 'Karan Kamble', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/karank/400/500' },
    { id: 10, name: 'Vaibhav Nakti', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/vaibhavn/400/500' },
    { id: 11, name: 'Bharat Kamble', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/bharat/400/500' },
    { id: 12, name: 'Sahil J. Patil', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/sahilj/400/500' },
    { id: 13, name: 'Sahil S. Patil', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/sahils/400/500' },
    { id: 14, name: 'Krunal Gharat', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/krunal/400/500' },
    { id: 15, name: 'Naush Patil', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/naush/400/500' },
    { id: 16, name: 'Raj Kamble', team: 'UK Warriors', role: 'Player', imageUrl: 'https://picsum.photos/seed/rajk/400/500' },
    { id: 17, name: 'Vikas Patil', team: 'UK Warriors', role: 'Coach', imageUrl: 'https://picsum.photos/seed/vikas/400/500' },
    { id: 18, name: 'Rahul Patil', team: 'UK Warriors', role: 'Coach', imageUrl: 'https://picsum.photos/seed/rahulp/400/500' },
    { id: 19, name: 'Dipesh Gharat', team: 'UK Warriors', role: 'Coach', imageUrl: 'https://picsum.photos/seed/dipesh/400/500' },
];

const SWARAJYA_SQUAD: Player[] = [
    // Staff
    { id: 16, name: 'Nitesh More', team: 'Swarajya CC', role: 'Team Owner', imageUrl: 'https://picsum.photos/seed/niteshm/400/500' },
    { id: 17, name: 'Shashi Bhayde', team: 'Swarajya CC', role: 'Batting Coach', imageUrl: 'https://picsum.photos/seed/shashi/400/500' },
    { id: 18, name: 'Kishor Chalke', team: 'Swarajya CC', role: 'Head Coach', imageUrl: 'https://picsum.photos/seed/kishor/400/500' },
    { id: 19, name: 'Shyam Khanloskar', team: 'Swarajya CC', role: 'Bowling Coach', imageUrl: 'https://picsum.photos/seed/shyam/400/500' },
    { id: 20, name: 'Vishal Bhayde', team: 'Swarajya CC', role: 'Fielding Coach', imageUrl: 'https://picsum.photos/seed/vishal/400/500' },
    // Players
    { id: 1, name: 'Rahul Chavan', team: 'Swarajya CC', role: 'Captain', category: 'Batsman', imageUrl: 'https://picsum.photos/seed/rahulc/400/500' },
    { id: 2, name: 'Sachin Vichare', team: 'Swarajya CC', role: 'Player', category: 'Batsman', imageUrl: 'https://picsum.photos/seed/sachinv/400/500' },
    { id: 3, name: 'Siddhesh Nakti', team: 'Swarajya CC', role: 'Player', category: 'Batsman', imageUrl: 'https://picsum.photos/seed/siddheshn/400/500' },
    { id: 4, name: 'Jaydip Patil', team: 'Swarajya CC', role: 'Player', category: 'All Rounder', imageUrl: 'https://picsum.photos/seed/jaydipp/400/500' },
    { id: 5, name: 'Kunal Kamble', team: 'Swarajya CC', role: 'Player', category: 'All Rounder', imageUrl: 'https://picsum.photos/seed/kunalk/400/500' },
    { id: 6, name: 'Pranal Nakti', team: 'Swarajya CC', role: 'Player', category: 'All Rounder', imageUrl: 'https://picsum.photos/seed/pranal/400/500' },
    { id: 7, name: 'Siddhesh Kamble', team: 'Swarajya CC', role: 'Player', category: 'All Rounder', imageUrl: 'https://picsum.photos/seed/siddheshk/400/500' },
    { id: 8, name: 'Raju Nakti', team: 'Swarajya CC', role: 'Vice-Captain', category: 'Bowler', imageUrl: 'https://picsum.photos/seed/raju/400/500' },
    { id: 9, name: 'Pravin Nakti', team: 'Swarajya CC', role: 'Player', category: 'Bowler', imageUrl: 'https://picsum.photos/seed/pravin/400/500' },
    { id: 10, name: 'Prasad Nakti', team: 'Swarajya CC', role: 'Player', category: 'Bowler', imageUrl: 'https://picsum.photos/seed/prasad/400/500' },
    { id: 11, name: 'Mahesh Mohite', team: 'Swarajya CC', role: 'Player', category: 'Bowler', imageUrl: 'https://picsum.photos/seed/mahesh/400/500' },
    { id: 12, name: 'Sagar Vichare', team: 'Swarajya CC', role: 'Player', category: 'Stand by', imageUrl: 'https://picsum.photos/seed/sagarv/400/500' },
    { id: 13, name: 'Sagar Kamble', team: 'Swarajya CC', role: 'Player', category: 'Stand by', imageUrl: 'https://picsum.photos/seed/sagark/400/500' },
    { id: 14, name: 'Sajan Bhayde', team: 'Swarajya CC', role: 'Player', category: 'Stand by', imageUrl: 'https://picsum.photos/seed/sajan/400/500' },
    { id: 15, name: 'Pratham Nakti', team: 'Swarajya CC', role: 'Player', category: 'Stand by', imageUrl: 'https://picsum.photos/seed/pratham/400/500' },
];

const DONGRI_JAKHAMATA_SQUAD: Player[] = [
  { id: 1, name: 'Prathamesh Bhayde', team: 'Dongri Jakhamata Boys', role: 'Captain', imageUrl: 'https://picsum.photos/seed/prathameshb/400/500' },
  { id: 2, name: 'Jay Nakti', team: 'Dongri Jakhamata Boys', role: 'Vice-Captain', imageUrl: 'https://picsum.photos/seed/jayn/400/500' },
  { id: 3, name: 'Jayesh Patil', team: 'Dongri Jakhamata Boys', role: 'Team Owner', imageUrl: 'https://picsum.photos/seed/jayeshp/400/500' },
  { id: 4, name: 'Yogesh Kamble', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/yogeshk/400/500' },
  { id: 5, name: 'Mayur Sishatkar', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/mayurs/400/500' },
  { id: 6, name: 'Prasad Patil', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/prasadp/400/500' },
  { id: 7, name: 'Pratap Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/pratapn/400/500' },
  { id: 8, name: 'Pranal Bhayde', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/pranalb/400/500' },
  { id: 9, name: 'Darshan Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/darshann/400/500' },
  { id: 10, name: 'Deepak Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/deepakn/400/500' },
  { id: 11, name: 'Ajay Baikar', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/ajayba/400/500' },
  { id: 12, name: 'Aakash Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/aakashn/400/500' },
  { id: 13, name: 'Manish Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/manishn/400/500' },
  { id: 14, name: 'Hastak Bhayde', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/hastakb/400/500' },
  { id: 15, name: 'Mahesh Patil', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/maheshp/400/500' },
  { id: 16, name: 'Tej Nakti', team: 'Dongri Jakhamata Boys', role: 'Player', imageUrl: 'https://picsum.photos/seed/tejn/400/500' },
];

const ROYAL_AAGRI_SQUAD: Player[] = [
    { id: 1, name: 'Vivek Patil', team: 'Royal Aagri Sports Club', role: 'Captain', imageUrl: 'https://picsum.photos/seed/vivekp/400/500' },
    { id: 2, name: 'Sushant Nakti', team: 'Royal Aagri Sports Club', role: 'Vice-Captain', imageUrl: 'https://picsum.photos/seed/sushantn/400/500' },
    { id: 3, name: 'Uddesh Nakti', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/uddeshn/400/500' },
    { id: 4, name: 'Sahil Patil', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/sahilp/400/500' },
    { id: 5, name: 'Ganesh Gharat', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/ganeshg/400/500' },
    { id: 6, name: 'Sushil Nakti', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/sushiln/400/500' },
    { id: 7, name: 'Ajinkya Bhayde', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/ajinkyab/400/500' },
    { id: 8, name: 'Omkar Mohite', team: 'Royal Aagri Sports Club', role: 'Wicket-Keeper', imageUrl: 'https://picsum.photos/seed/omkarm/400/500' },
    { id: 9, name: 'Vivek Bhayde', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/vivekb/400/500' },
    { id: 10, name: 'Akash Mohite', team: 'Royal Aagri Sports Club', role: 'Wicket-Keeper', imageUrl: 'https://picsum.photos/seed/akashm/400/500' },
    { id: 11, name: 'Vishal Bhayde', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/vishalb/400/500' },
    { id: 12, name: 'Sajan Patil', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/sajanp/400/500' },
    { id: 13, name: 'Prasad Mohite', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/prasadm/400/500' },
    { id: 14, name: 'Shubham Nakti', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/shubhamn/400/500' },
    { id: 15, name: 'Prashant Mohite', team: 'Royal Aagri Sports Club', role: 'Player', imageUrl: 'https://picsum.photos/seed/prashantm/400/500' },
];

const GAME_CHANGERS_SQUAD: Player[] = [
    { id: 1, name: 'Raj Nakti', team: 'Game Changers', role: 'Captain', imageUrl: 'https://picsum.photos/seed/rajnaktigc/400/500' },
    { id: 2, name: 'Pramod Nakti', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/pramodn/400/500' },
    { id: 3, name: 'Dipesh Nakti', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/dipeshn/400/500' },
    { id: 4, name: 'Prakash Nakti', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/prakashn/400/500' },
    { id: 5, name: 'Rohit Nakti', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/rohitn/400/500' },
    { id: 6, name: 'Bharat Patil', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/bharatp/400/500' },
    { id: 7, name: 'Ajinkya Patil', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/ajinkyap/400/500' },
    { id: 8, name: 'Tushar Chalke', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/tusharc/400/500' },
    { id: 9, name: 'Devesh Nakti', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/deveshn/400/500' },
    { id: 10, name: 'Aniket Chalke', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/aniket/400/500' },
    { id: 11, name: 'Raj Kamble', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/rajkgc/400/500' },
    { id: 12, name: 'Sudarshan Chalke', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/sudarshan/400/500' },
    { id: 13, name: 'Hardik Mohite', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/hardikm/400/500' },
    { id: 14, name: 'Ved Patil', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/vedp/400/500' },
    { id: 15, name: 'Athrav Biradi', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/athravb/400/500' },
    { id: 16, name: 'Santosh Patil', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/santoshp/400/500' },
    { id: 17, name: 'Vishal Chalke', team: 'Game Changers', role: 'Player', imageUrl: 'https://picsum.photos/seed/vishalc/400/500' },
];

export const TEAMS: Team[] = [
    { 
        name: 'Rising Stars', 
        logo: RISING_STARS_LOGO,
        squad: RISING_STARS_SQUAD,
        theme: {
            gradientFrom: 'from-yellow-500',
            gradientVia: 'via-purple-800',
            gradientTo: 'to-rose-900',
            accent: 'text-yellow-200',
            heroTextColor: 'text-white'
        }
    },
    { 
        name: 'UK Warriors', 
        logo: UK_WARRIORS_LOGO,
        squad: UK_WARRIORS_SQUAD,
        theme: {
            gradientFrom: 'from-amber-400',
            gradientVia: 'via-yellow-600',
            gradientTo: 'to-orange-800',
            accent: 'text-yellow-900',
            heroTextColor: 'text-slate-900'
        }
    },
    { 
        name: 'Swarajya CC', 
        logo: SWARAJYA_LOGO,
        squad: SWARAJYA_SQUAD,
        displayFormat: 'grouped_staff',
        theme: {
            gradientFrom: 'from-blue-500',
            gradientVia: 'via-orange-500',
            gradientTo: 'to-blue-800',
            accent: 'text-orange-300',
            heroTextColor: 'text-white'
        }
    },
    { 
        name: 'Dongri Jakhamata Boys', 
        logo: DJB_LOGO,
        squad: DONGRI_JAKHAMATA_SQUAD,
        theme: {
            gradientFrom: 'from-cyan-400',
            gradientVia: 'via-blue-600',
            gradientTo: 'to-orange-500',
            accent: 'text-orange-300',
            heroTextColor: 'text-white'
        }
    },
    { 
        name: 'Royal Aagri Sports Club', 
        logo: ROYAL_AAGRI_LOGO,
        squad: ROYAL_AAGRI_SQUAD,
        theme: {
            gradientFrom: 'from-purple-600',
            gradientVia: 'via-fuchsia-600',
            gradientTo: 'to-purple-900',
            accent: 'text-fuchsia-300',
            heroTextColor: 'text-white'
        }
    },
    { 
        name: 'Game Changers', 
        logo: GAME_CHANGERS_LOGO,
        squad: GAME_CHANGERS_SQUAD,
        theme: {
            gradientFrom: 'from-amber-800',
            gradientVia: 'via-yellow-500',
            gradientTo: 'to-amber-900',
            accent: 'text-yellow-300',
            heroTextColor: 'text-white'
        }
    }
];

const matchups = [
    // Group Stage
    { teamA: 'Swarajya CC', teamB: 'Rising Stars', stage: 'Group Stage' },
    { teamA: 'Dongri Jakhamata Boys', teamB: 'Royal Aagri Sports Club', stage: 'Group Stage' },
    { teamA: 'UK Warriors', teamB: 'Game Changers', stage: 'Group Stage' },
    { teamA: 'Swarajya CC', teamB: 'Dongri Jakhamata Boys', stage: 'Group Stage' },
    { teamA: 'Royal Aagri Sports Club', teamB: 'Game Changers', stage: 'Group Stage' },
    { teamA: 'UK Warriors', teamB: 'Rising Stars', stage: 'Group Stage' },
    { teamA: 'Dongri Jakhamata Boys', teamB: 'Game Changers', stage: 'Group Stage' },
    { teamA: 'Swarajya CC', teamB: 'UK Warriors', stage: 'Group Stage' },
    { teamA: 'Royal Aagri Sports Club', teamB: 'Rising Stars', stage: 'Group Stage' },
    { teamA: 'Game Changers', teamB: 'Swarajya CC', stage: 'Group Stage' },
    { teamA: 'Royal Aagri Sports Club', teamB: 'UK Warriors', stage: 'Group Stage' },
    { teamA: 'Dongri Jakhamata Boys', teamB: 'Rising Stars', stage: 'Group Stage' },
    { teamA: 'Swarajya CC', teamB: 'Royal Aagri Sports Club', stage: 'Group Stage' },
    { teamA: 'Rising Stars', teamB: 'Game Changers', stage: 'Group Stage' },
    { teamA: 'UK Warriors', teamB: 'Dongri Jakhamata Boys', stage: 'Group Stage' },
    
    // Knockouts
    { teamA: 'TBD 1', teamB: 'TBD 2', stage: 'Semi-Final 1' },
    { teamA: 'TBD 3', teamB: 'TBD 4', stage: 'Semi-Final 2' },
    { teamA: 'Winner SF1', teamB: 'Winner SF2', stage: 'Final' },
];

const allPlayersByName = TEAMS.reduce((acc, team) => {
    const staffRoles = ['Team Owner', 'Team Manager', 'Batting Coach', 'Bowling Coach', 'Head Coach', 'Fielding Coach', 'Coach'];
    const players = team.squad.filter(p => !staffRoles.includes(p.role));
    acc[team.name] = players.map(p => p.name);
    return acc;
}, {} as Record<string, string[]>);

const tournamentStartDate = new Date('2025-09-03T11:00:00');

export const MATCHES: Match[] = matchups.map((matchup, index) => {
    const matchDate = new Date(tournamentStartDate.getTime() + index * 30 * 60 * 1000);
    
    const teamAPlayers = allPlayersByName[matchup.teamA];
    const teamBPlayers = allPlayersByName[matchup.teamB];
    
    return {
        id: index + 1,
        teamA: matchup.teamA,
        teamB: matchup.teamB,
        date: matchDate,
        venue: 'Wakde Mal, Shiste',
        stage: matchup.stage,
        playing11A: teamAPlayers ? teamAPlayers.slice(0, 11) : undefined,
        playing11B: teamBPlayers ? teamBPlayers.slice(0, 11) : undefined,
    };
});