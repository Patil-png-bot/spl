export interface Player {
  id: number;
  name: string;
  team: string;
  role: 'Captain' | 'Vice-Captain' | 'Coach' | 'Player' | 'Team Owner' | 'Team Manager' | 'Batting Coach' | 'Bowling Coach' | 'Head Coach' | 'Fielding Coach' | 'Wicket-Keeper';
  category?: 'Batsman' | 'All Rounder' | 'Bowler' | 'Stand by';
  imageUrl: string;
}

export interface Team {
    name: string;
    logo: string;
    squad: Player[];
    theme: {
        gradientFrom: string;
        gradientVia: string;
        gradientTo:string;
        accent: string;
        heroTextColor: string;
    };
    displayFormat?: 'default' | 'grouped_staff';
}

export interface Match {
  id: number;
  teamA: string;
  teamB: string;
  date: Date;
  venue: string;
  stage: string;
  playing11A?: string[];
  playing11B?: string[];
}